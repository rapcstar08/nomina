
import { useState } from "react";
import { categories } from "./data/categories";
import { formatCurrency } from "./utils/format";

export default function App() {
  const [expenses, setExpenses] = useState([]);
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("Food");

  const addExpense = () => {
    if (!amount || isNaN(amount)) return;
    const newExpense = {
      id: Date.now(),
      category,
      amount: parseFloat(amount),
    };
    setExpenses([newExpense, ...expenses]);
    setAmount("");
  };

  const total = expenses.reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="min-h-screen bg-[#1e1e1e] text-white p-6 font-sans">
      <div className="max-w-md mx-auto">
        <h1 className="text-2xl font-semibold mb-4">Nomina</h1>

        <div className="flex flex-col gap-3 mb-6">
          <input
            type="number"
            placeholder="Amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="bg-[#2c2c2c] border border-gray-700 rounded-lg p-2"
          />
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="bg-[#2c2c2c] border border-gray-700 rounded-lg p-2"
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
          <button
            onClick={addExpense}
            className="bg-gray-600 hover:bg-gray-500 rounded-lg py-2"
          >
            Add Expense
          </button>
        </div>

        <div className="text-lg font-medium mb-4">
          Total: {formatCurrency(total)}
        </div>

        <ul className="space-y-2">
          {expenses.map((item) => (
            <li
              key={item.id}
              className="bg-[#2a2a2a] p-3 rounded-lg border border-gray-700 flex justify-between"
            >
              <span>{item.category}</span>
              <span>{formatCurrency(item.amount)}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
